<?php
namespace App\GP247\Front\Admin\Controllers;

use GP247\Front\Admin\Controllers\AdminLinkGroupController as VendorAdminLinkGroupController;

class AdminLinkGroupController extends VendorAdminLinkGroupController
{
    public function __construct()
    {
        parent::__construct();
    }
}
