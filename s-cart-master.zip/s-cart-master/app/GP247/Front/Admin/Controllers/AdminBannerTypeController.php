<?php
namespace App\GP247\Front\Admin\Controllers;

use GP247\Front\Admin\Controllers\AdminBannerTypeController as VendorAdminBannerTypeController;
class AdminBannerTypeController extends VendorAdminBannerTypeController
{
    public function __construct()
    {
        parent::__construct();
    }
}
