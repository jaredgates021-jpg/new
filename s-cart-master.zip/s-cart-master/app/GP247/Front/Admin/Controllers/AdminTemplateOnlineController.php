<?php
namespace App\GP247\Front\Admin\Controllers;

use GP247\Front\Admin\Controllers\AdminTemplateOnlineController as VendorAdminTemplateOnlineController;

class AdminTemplateOnlineController extends VendorAdminTemplateOnlineController
{
    public function __construct()
    {
        parent::__construct();
    }
}
