<?php
namespace App\GP247\Front\Admin\Controllers;


use GP247\Front\Admin\Controllers\AdminBannerController as VendorAdminBannerController;

class AdminBannerController extends VendorAdminBannerController
{

    public function __construct()
    {
        parent::__construct();
    }
}
