<?php
namespace App\GP247\Front\Admin\Controllers;

use GP247\Front\Admin\Controllers\AdminPageController as VendorAdminPageController;

class AdminPageController extends VendorAdminPageController
{
   
    public function __construct()
    {
        parent::__construct();
    }
}

