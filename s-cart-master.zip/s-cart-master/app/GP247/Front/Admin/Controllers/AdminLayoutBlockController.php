<?php
namespace App\GP247\Front\Admin\Controllers;

use GP247\Front\Admin\Controllers\AdminLayoutBlockController as VendorAdminLayoutBlockController;

class AdminLayoutBlockController extends VendorAdminLayoutBlockController
{
    public function __construct()
    {
        parent::__construct();
    }
}
