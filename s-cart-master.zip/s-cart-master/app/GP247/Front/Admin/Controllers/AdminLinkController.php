<?php
namespace App\GP247\Front\Admin\Controllers;

use GP247\Front\Admin\Controllers\AdminLinkController as VendorAdminLinkController;

class AdminLinkController extends VendorAdminLinkController
{
    public function __construct()
    {
        parent::__construct();
    }
}
