<?php
namespace App\GP247\Front\Controllers;

use GP247\Front\Controllers\HomeController as VendorHomeController;

class HomeController extends VendorHomeController
{

    public function __construct()
    {
        parent::__construct();
    }
}
