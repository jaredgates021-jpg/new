<?php
namespace App\GP247\Core\Controllers;

use GP247\Core\Controllers\AdminNoticeController as VendorAdminNoticeController;

class AdminNoticeController extends VendorAdminNoticeController
{
    public function __construct()
    {
        parent::__construct();
    }
}
