<?php

namespace App\GP247\Core\Controllers;

use GP247\Core\Controllers\AdminServerInfoController as VendorAdminServerInfoController;

class AdminServerInfoController extends VendorAdminServerInfoController
{

} 