<?php
namespace App\GP247\Core\Controllers;

use GP247\Core\Controllers\AdminCacheConfigController as VendorAdminCacheConfigController;

class AdminCacheConfigController extends VendorAdminCacheConfigController
{
    public function __construct()
    {
        parent::__construct();
    }
}
