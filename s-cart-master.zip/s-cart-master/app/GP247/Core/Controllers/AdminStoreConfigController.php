<?php
namespace App\GP247\Core\Controllers;

use GP247\Core\Controllers\AdminStoreConfigController as VendorAdminStoreConfigController;

class AdminStoreConfigController extends VendorAdminStoreConfigController
{
    public function __construct()
    {
        parent::__construct();
    }
}
