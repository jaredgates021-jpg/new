<?php
namespace App\GP247\Core\Controllers;

use GP247\Core\Controllers\AdminHomeLayoutController as VendorAdminHomeLayoutController;

class AdminHomeLayoutController extends VendorAdminHomeLayoutController
{
    public function __construct()
    {
        parent::__construct();
    }
}
