<?php
namespace App\GP247\Core\Controllers;

use GP247\Core\Controllers\AdminStoreInfoController as VendorAdminStoreInfoController;
class AdminStoreInfoController extends VendorAdminStoreInfoController
{

    public function __construct()
    {
        parent::__construct();
    }

}
