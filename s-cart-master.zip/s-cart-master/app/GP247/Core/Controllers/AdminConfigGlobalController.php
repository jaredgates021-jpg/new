<?php
namespace App\GP247\Core\Controllers;

use GP247\Core\Controllers\AdminConfigGlobalController as VendorAdminConfigGlobalController;

class AdminConfigGlobalController extends VendorAdminConfigGlobalController
{

    public function __construct()
    {
        parent::__construct();
    }

}
