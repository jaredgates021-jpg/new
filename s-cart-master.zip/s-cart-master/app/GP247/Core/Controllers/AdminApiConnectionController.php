<?php
namespace App\GP247\Core\Controllers;

use GP247\Core\Controllers\AdminApiConnectionController as VendorAdminApiConnectionController;

class AdminApiConnectionController extends VendorAdminApiConnectionController
{
    public function __construct()
    {
        parent::__construct();
    }
}
