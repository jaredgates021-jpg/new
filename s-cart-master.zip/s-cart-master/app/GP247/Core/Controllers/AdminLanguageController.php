<?php
namespace App\GP247\Core\Controllers;

use GP247\Core\Controllers\AdminLanguageController as VendorAdminLanguageController;

class AdminLanguageController extends VendorAdminLanguageController
{
    public function __construct()
    {
        parent::__construct();
    }
}
