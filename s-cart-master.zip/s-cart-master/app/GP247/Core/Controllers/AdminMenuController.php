<?php
namespace App\GP247\Core\Controllers;


use GP247\Core\Controllers\AdminMenuController as VendorAdminMenuController;

class AdminMenuController extends VendorAdminMenuController
{
    public function __construct()
    {
        parent::__construct();
    }
}
