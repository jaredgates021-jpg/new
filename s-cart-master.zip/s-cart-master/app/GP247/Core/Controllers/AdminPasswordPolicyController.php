<?php
namespace App\GP247\Core\Controllers;

use GP247\Core\Controllers\AdminPasswordPolicyController as VendorAdminPasswordPolicyController;

class AdminPasswordPolicyController extends VendorAdminPasswordPolicyController
{

    public function __construct()
    {
        parent::__construct();
    }
}
