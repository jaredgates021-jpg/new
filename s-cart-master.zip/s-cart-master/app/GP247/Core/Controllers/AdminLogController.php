<?php
namespace App\GP247\Core\Controllers;


use GP247\Core\Controllers\AdminLogController as VendorAdminLogController;

class AdminLogController extends VendorAdminLogController
{
    public function __construct()
    {
        parent::__construct();
    }
}
