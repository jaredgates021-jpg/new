<?php
namespace App\GP247\Core\Controllers;

use GP247\Core\Controllers\AdminPluginsController as VendorAdminPluginsController;

class AdminPluginsController extends VendorAdminPluginsController
{
    public function __construct()
    {
        parent::__construct();
    }
}
