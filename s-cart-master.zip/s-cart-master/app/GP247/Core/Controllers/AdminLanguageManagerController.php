<?php
namespace App\GP247\Core\Controllers;

use GP247\Core\Controllers\AdminLanguageManagerController as VendorAdminLanguageManagerController;

class AdminLanguageManagerController extends VendorAdminLanguageManagerController
{
    public function __construct()
    {
        parent::__construct();
    }
}
