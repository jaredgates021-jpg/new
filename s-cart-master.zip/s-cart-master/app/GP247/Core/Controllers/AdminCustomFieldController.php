<?php
namespace App\GP247\Core\Controllers;

use GP247\Core\Controllers\AdminCustomFieldController as VendorAdminCustomFieldController;

class AdminCustomFieldController extends VendorAdminCustomFieldController
{

    public function __construct()
    {
        parent::__construct();
    }
}
