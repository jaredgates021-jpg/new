<?php
namespace App\GP247\Core\Controllers;

use GP247\Core\Controllers\AdminStoreMaintainController as VendorAdminStoreMaintainController;

class AdminStoreMaintainController extends VendorAdminStoreMaintainController
{
    public function __construct()
    {
        parent::__construct();
    }
}
