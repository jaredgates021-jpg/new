<?php

namespace App\GP247\Core\Controllers;

use GP247\Core\Controllers\HomeController as CoreHomeController;

class HomeController extends CoreHomeController
{
    public function __construct()
    {
        parent::__construct();
    }
}
