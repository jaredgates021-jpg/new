<?php
namespace App\GP247\Core\Controllers;

use GP247\Core\Controllers\AdminPluginsOnlineController as VendorAdminPluginsOnlineController;
class AdminPluginsOnlineController extends VendorAdminPluginsOnlineController
{
    public function __construct()
    {
        parent::__construct();
    }

}
