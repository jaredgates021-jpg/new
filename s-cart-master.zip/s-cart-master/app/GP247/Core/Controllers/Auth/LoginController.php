<?php

namespace App\GP247\Core\Controllers\Auth;

use GP247\Core\Controllers\Auth\LoginController as VendorLoginController;
class LoginController extends VendorLoginController
{
    public function __construct()
    {
        parent::__construct();
    }
}
