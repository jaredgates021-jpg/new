<?php
namespace App\GP247\Core\Controllers\Auth;

use GP247\Core\Controllers\Auth\UsersController as VendorUsersController;


class UsersController extends VendorUsersController
{
    public function __construct()
    {
        parent::__construct();
    }
}
