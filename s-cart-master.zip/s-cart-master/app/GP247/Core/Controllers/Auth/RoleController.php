<?php
namespace App\GP247\Core\Controllers\Auth;

use GP247\Core\Controllers\Auth\RoleController as VendorRoleController;

class RoleController extends VendorRoleController
{
    public function __construct()
    {
        parent::__construct();
    }
}
