<?php

namespace App\GP247\Core\Controllers\Auth;

use GP247\Core\Controllers\Auth\ResetPasswordController as VendorResetPasswordController;

class ResetPasswordController extends VendorResetPasswordController
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct(); 
    }
}
