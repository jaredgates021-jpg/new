<?php

namespace App\GP247\Core\Api\Controllers;

use GP247\Core\Api\Controllers\AdminAuthController as VendorAdminAuthController;

class AdminAuthController extends VendorAdminAuthController
{
    public function __construct()
    {
        parent::__construct();
    }
}
