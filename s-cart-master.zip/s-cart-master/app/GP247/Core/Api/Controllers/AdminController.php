<?php

namespace App\GP247\Core\Api\Controllers;

use GP247\Core\Api\Controllers\AdminController as VendorAdminController;

class AdminController extends VendorAdminController
{
    public function __construct()
    {
        parent::__construct();
    }
}
