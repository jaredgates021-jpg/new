<?php
namespace App\GP247\Shop\Controllers;

use GP247\Shop\Controllers\ShopBrandController as VendorShopBrandController;

class ShopBrandController extends VendorShopBrandController
{
    public function __construct()
    {
        parent::__construct();
    }
}
