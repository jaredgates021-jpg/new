<?php

namespace App\GP247\Shop\Controllers\Auth;

use GP247\Shop\Controllers\Auth\RegisterController as VendorRegisterController;

class RegisterController extends VendorRegisterController
{
    public function __construct()
    {
        parent::__construct();
    }
}
