<?php

namespace App\GP247\Shop\Controllers\Auth;

use GP247\Shop\Controllers\Auth\ResetPasswordController as VendorResetPasswordController;

class ResetPasswordController extends VendorResetPasswordController
{

    public function __construct()
    {
        parent::__construct();
    }
}
