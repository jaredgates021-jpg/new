<?php

namespace App\GP247\Shop\Controllers\Auth;

use GP247\Shop\Controllers\Auth\ForgotPasswordController as VendorForgotPasswordController;

class ForgotPasswordController extends VendorForgotPasswordController
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }
}
