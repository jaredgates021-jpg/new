<?php
namespace App\GP247\Shop\Controllers;

use GP247\Shop\Controllers\ShopCartController as VendorShopCartController;

class ShopCartController extends VendorShopCartController
{

    public function __construct()
    {
        parent::__construct();
    }
}
