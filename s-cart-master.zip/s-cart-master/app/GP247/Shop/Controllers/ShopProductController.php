<?php
namespace App\GP247\Shop\Controllers;

use GP247\Shop\Controllers\ShopProductController as VendorShopProductController;

class ShopProductController extends VendorShopProductController
{
    public function __construct()
    {
        parent::__construct();
    }
}
