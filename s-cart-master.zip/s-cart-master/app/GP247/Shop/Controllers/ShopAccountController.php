<?php
namespace App\GP247\Shop\Controllers;

use GP247\Shop\Controllers\ShopAccountController as VendorShopAccountController;

class ShopAccountController extends VendorShopAccountController
{

    public function __construct()
    {
        parent::__construct();
    }
}
