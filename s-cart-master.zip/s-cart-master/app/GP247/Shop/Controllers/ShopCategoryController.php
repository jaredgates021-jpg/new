<?php
namespace App\GP247\Shop\Controllers;

use GP247\Shop\Controllers\ShopCategoryController as VendorShopCategoryController;

class ShopCategoryController extends VendorShopCategoryController
{
    public function __construct()
    {
        parent::__construct();
    }
}
