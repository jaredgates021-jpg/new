<?php
namespace App\GP247\Shop\Controllers;

use GP247\Shop\Controllers\ShopStoreController as VendorShopStoreController;

class ShopStoreController extends VendorShopStoreController
{
    public function __construct()
    {
        parent::__construct();
    }
}
