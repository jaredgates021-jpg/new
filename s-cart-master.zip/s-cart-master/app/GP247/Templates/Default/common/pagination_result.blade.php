<p class="product-top-panel-title">
  {!! gp247_language_render('front.result_item', ['item_from' => $items->firstItem(), 'item_to'=> $items->lastItem(), 'total'=> $items->total()  ]) !!}
</p>