<div id="maintenance_note">{!! gp247_store_info('maintain_note') !!}</div>
@push('styles')
  <style>
    #maintenance_note {
      display: block;
      color:red;
      z-index: 9999;
      font-size: 25px;
    }
  </style>
@endpush