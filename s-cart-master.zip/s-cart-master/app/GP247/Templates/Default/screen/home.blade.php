@php
/*
$layout_page = front_home
*/ 
@endphp

@extends($GP247TemplatePath.'.layout')

@section('block_main')
@endsection

@push('styles')
{{-- Your css style --}}
@endpush

@push('scripts')
{{-- //script here --}}
@endpush
