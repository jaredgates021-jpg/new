<?php
return [
    'title'      => 'Default',
    'admin'      => [
        'title'          => 'Default',
    ],
];
