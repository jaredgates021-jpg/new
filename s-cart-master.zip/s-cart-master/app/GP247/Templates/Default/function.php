<?php
//Function helper here
