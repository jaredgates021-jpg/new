<?php

return 
[
    // List functions helpers gp247_xx will inactive
    // example: 'gp247_function1', 'gp247_function2',
];