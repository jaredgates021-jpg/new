<?php

use Illuminate\Support\Facades\Route;
//GP247 comment
// Route::get('/', function () {
//     return view('welcome');
// });
